/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dander73_sql;

import java.sql.*;


/**
 *
 * @author dwanderson
 */
public class QueryBean {
    private static String year = "";
    private static String month = "";
    private static String day = "";
    private static String resultTable = "";
    private static boolean valid = false;
    private static String error = "";
    
    private static final String host = "web7.apl.jhu.edu";
    private static final String dbName = "class";
    private static final int port = 3306;
    private static final String dbUrl = "jdbc:mysql://" + host + ":" + port + "/" + dbName;
    private static final String username = "johncolter";
    private static final String password = "LetMeIn";

    /**
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * @param aError the error to set
     */
    public void setError(String aError) {
        error = aError;
    }

    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * @param aYear the year to set
     */
    public void setYear(String aYear) {
        year = aYear;
    }

    /**
     * @return the month
     */
    public String getMonth() {
        return month;
    }

    /**
     * @param aMonth the month to set
     */
    public void setMonth(String aMonth) {
        if (aMonth.length() == 1) {
            aMonth = "0" + aMonth;
        }
        month = aMonth;
    }

    /**
     * @return the day
     */
    public String getDay() {
        return day;
    }

    /**
     * @param aDay the day to set
     */
    public void setDay(String aDay) {
        if (aDay.length() == 1) {
            aDay = "0" + aDay;
        }
        day = aDay;
    }

    /**
     * @return the resultTable
     */
    public String getResultTable() {
        return resultTable;
    }

    /**
     * @param aResultTable the resultTable to set
     */
    public void setResultTable(String aResultTable) {
        resultTable = aResultTable;
    }

    public void setValid(boolean aValid) {
        valid = aValid;
    }
    
    public boolean isValid() {
        String startDay = getYear() + getMonth() + getDay();
        resultTable = "<table cellpadding=\"2\" border=\"3\"> <caption align=\"top\"" +
                "Reservations after " + startDay + "</caption> <tr> <th> Date </th> " +
                "<th> Last </th> <th> First </th> <th> Location </th> </tr>";
        
        try {
            String driver = "com.mysql.jdbc.Driver";
            Class.forName(driver).newInstance();
            Connection connection = DriverManager.getConnection(dbUrl, username, password);
            Statement st = connection.createStatement();
            String selectors = "reservation.First, reservation.Last, " + 
                    "reservation.StartDay, locations.location";
            String dbs = "reservation, guides, locations";
            String where = "reservation.guide = guides.idguides and " +
                    "reservation.location = locations.idlocations and " +
                    "reservation.StartDay > " + startDay;
            String order = "reservation.StartDay ASC, reservation.Last ASC";
            String call = "select " + selectors + " from " + dbs + " where " + where + 
                    " ORDER BY " + order;
            ResultSet rs = st.executeQuery(call);
            while (rs.next()) {
                String first = rs.getString("reservation.First");
                String last = rs.getString("reservation.Last");
                String date = rs.getString("reservation.StartDay");
                String loc = rs.getString("locations.location");
                resultTable += "<tr> <td> " + date + "</td> <td> " + last + "</td> <td> " + 
                        first + "</td> <td> " + loc + "</td> </tr>";
            }
        } catch (SQLException sqle) {
            setError("Couldn't connect to " + dbUrl + " " + sqle.toString());
            return false;
        } catch (Exception e) {
            setError("Non-SQL exception: " + e.toString());
            return false;
        }
        resultTable += "</table>";
        return true;
    }
}
