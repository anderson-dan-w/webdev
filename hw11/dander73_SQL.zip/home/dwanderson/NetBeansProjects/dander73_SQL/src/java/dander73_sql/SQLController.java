/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dander73_sql;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author dwanderson
 */
@WebServlet(name = "SQLController", urlPatterns = {"/SQLController"})
public class SQLController extends HttpServlet {
    public static final String QUERYBEAN = "queryBean";
    public static final String YEAR = "year";
    public static final String MONTH = "month";
    public static final String DAY = "day";
    public static final String TABLE = "resultTable";
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        ServletContext servletContext = getServletContext();
        QueryBean query = (QueryBean) session.getAttribute(QUERYBEAN);
        if (query == null) {
            query = new QueryBean();
            session.setAttribute(QUERYBEAN, query);
            RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/queryEntry.jsp");
            dispatcher.forward(request, response);
        } else {
            String year = request.getParameter(YEAR);
            String month = request.getParameter(MONTH);
            String day = request.getParameter(DAY);
            
            if (year == null) {
                year = "0";
            }
            if (month == null) {
                month = "1";            
            }
            if (day == null) {
                day = "1";
            }
            query.setYear(year);
            query.setMonth(month);
            query.setDay(day);
            // geYear() = "0" is a default; force it to go to queryEntry
            if (!(query.getYear().equals("0")) && (query.isValid())) {
                RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/queryResults.jsp");
                dispatcher.forward(request, response);
            } else {
                RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/queryEntry.jsp");
                dispatcher.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
