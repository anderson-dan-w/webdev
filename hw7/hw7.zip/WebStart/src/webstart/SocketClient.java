/*
 * Dan W Anderson
 */

package webstart;

/**
 *
 * @author dwanderson
 */
import java.io.*;
import java.net.*;

/**
 *
 * @author evansrb1
 */
public class SocketClient {

    public String getRate(String formattedString) {

        String rateInfo = "";
        Socket echoSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;
        try {
            System.out.println("Making the Socket...");
            echoSocket = new Socket("web7.apl.jhu.edu", 20025);
            System.out.println("Making the PrintWriter...");            
            out = new PrintWriter(echoSocket.getOutputStream(), true);
            System.out.println("Making the BufferedReader...");                        
            in = new BufferedReader(new InputStreamReader(
                                        echoSocket.getInputStream()));
            out.println(formattedString);
            rateInfo = in.readLine();
        } catch (UnknownHostException e) {
            //System.err.println("Don't know about host: web7.apl.jhu.edu");
            rateInfo = "Don't know about host: web7.apl.jhu.edu";
            //System.exit(1);
        } catch (IOException e) {
            rateInfo = "Couldn't get I/O for the connection to: web7.apl.jhu.edu.";
        }

	out.close();
        try {
            in.close();
            echoSocket.close();
        } catch (IOException e) {
            //
        }
        return rateInfo;
    }
    
    public String getRate(BookingDay startDate, BookingDay endDate, Hike hike) {
        String infoString = "";
        infoString += startDate.getYear() + ":" + startDate.getMonth() + ":" +
                startDate.getDayOfMonth() + ":";
        infoString += endDate.getYear() + ":" + endDate.getMonth() + ":" +
                endDate.getDayOfMonth() + ":";
        infoString += (int)Math.round(hike.getBaseRate());
        String rateString = getRate(infoString);
        return rateString;
    }
}
