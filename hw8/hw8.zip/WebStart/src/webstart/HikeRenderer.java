/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webstart;

import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;

/**
 *
 * @author dwanderson
 */
        
public class HikeRenderer extends DefaultListCellRenderer {
    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean hasFocus) {
        JLabel renderer = (JLabel)(super.getListCellRendererComponent(list, value, index, isSelected, hasFocus));
        if (value instanceof Hike) {
            Hike hike = (Hike)value;
            renderer.setText(hike.getName() + ", a hike of " + hike.getDifficulty() + " difficulty.");
            renderer.setToolTipText("Hikes of " + hike.getLengths() +
                    " days at $" + hike.getBaseRate() + "/day.");
        }
        return renderer;
    }
}
