/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webstart;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author dwanderson
 */
public class Hike {
    private String name;
    private String difficulty;
    private double baseRate;
    private List<Integer> lengths;
    private DefaultComboBoxModel lengthComboBox;
    
    public Hike(String name, String difficulty, double baseRate, List<Integer> lengths) {
        this.name = name;
        this.difficulty = difficulty;
        this.baseRate = baseRate;
        this.lengths = lengths;
        Object[] hikeLengths = this.lengths.toArray();
        this.lengthComboBox = new DefaultComboBoxModel(hikeLengths);
    }
    
    public Hike(String name, String difficulty, double baseRate, int[] lengths) {
        this.name = name;
        this.difficulty = difficulty;
        this.baseRate = baseRate;
        List<Integer> lengthList = new ArrayList<>();
        for (int i=0; i<lengths.length; i++) {
            lengthList.add(lengths[i]);
        }
        this.lengths = lengthList;
        Object[] hikeLengths = this.lengths.toArray();
        this.lengthComboBox = new DefaultComboBoxModel(hikeLengths);
    }
    
    public static Hike[] makeHikes() {
        Hike[] hikes = new Hike[3];
        
        int[] gLLengths = {3, 5};
        hikes[0] = new Hike("Gardiner Lake", "Intermediate", 40.00, gLLengths);
        
        int[] hPLengths = {2, 3, 4};
        hikes[1] = new Hike("Hellroaring Plateau", "Easy", 35.00, hPLengths);
        
        int[] bPLengths = {5, 6, 7};
        hikes[2] = new Hike("The Beaten Path", "Difficult", 45.00, bPLengths);
        return hikes;
    }
    
    /**
     * Creates a Map of all pre-determined hikes, where the key is the hike name
     * and the value is the Hike object.
     * @return 
     */
    public static Map<String, Hike> makeHikeMap() {
        Map<String, Hike> hikeMap = new HashMap<String, Hike>();
        for (Hike hike: makeHikes()) {
            hikeMap.put(hike.getName(), hike);
        }
        return hikeMap;        
    }
    
    public static DefaultComboBoxModel[] makeHikeLengthsComboBoxes(Hike[] hikes) {
        DefaultComboBoxModel[] dcbm = new DefaultComboBoxModel[hikes.length + 1];
        for (int i=0; i<hikes.length; i++) {
            Object[] hikeLengths = hikes[i].getLengths().toArray();
            dcbm[i] = new DefaultComboBoxModel(hikeLengths);
        }
        // Make the last element an empty ComboBox, for when no hike is selected
        dcbm[hikes.length] = new DefaultComboBoxModel();
        return dcbm;
    }
    
    /**
     * Calculates the rate of a particular hike, over a set of particular days.
     * This ensures that the hike is of appropriate length, and takes into
     * consideration weekend rates.
     * @param beginDay
     * @param endDay
     * @return 
     */
    public Rates calculateRate(BookingDay beginDay, BookingDay endDay) {
        Rates rate = new Rates();
        rate.setBaseRate(getBaseRate());
        rate.setBeginDate(beginDay);
        rate.setEndDate(endDay);
        // rate.isValidDates sets rate.details only if there was an error
        if (rate.isValidDates()) {
            if (isValidLength(rate.getNormalDays() + rate.getPremiumDays()) != true) {
                rate.setDetails("Sorry, this hike can only be " +
                        this.lengths + " days but you asked for" +
                        (rate.getNormalDays() + rate.getPremiumDays()) + "days.");
            }       
        }
        return rate;
    }
    
    /**
     * Determines whether or not a supplied length is an appropriate length, for
     * a given hike. 
     * @param length Length of hike in days, inclusive of start and end day.
     * @return 
     */
    public boolean isValidLength(int length) {
        boolean isValid = false;
        for (int i=0; i<lengths.size(); i++) {
            if (lengths.get(i) == length) {
                isValid = true;
                break;
            }
        }
        return isValid;
    }
    
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param aName the name to set
     */
    public void setName(String aName) {
        name = aName;
    }

    /**
     * @return the difficulty
     */
    public String getDifficulty() {
        return difficulty;
    }

    /**
     * @param aDifficulty the difficulty to set
     */
    public void setDifficulty(String aDifficulty) {
        difficulty = aDifficulty;
    }

    /**
     * @return the baseRate
     */
    public double getBaseRate() {
        return baseRate;
    }

    /**
     * @param aBaseRate the baseRate to set
     */
    public void setBaseRate(double aBaseRate) {
        baseRate = aBaseRate;
    }

    /**
     * @return the lengths
     */
    public List<Integer> getLengths() {
        return lengths;
    }

    /**
     * @param aLengths the lengths to set
     */
    public void setLengths(List<Integer> aLengths) {
        lengths = aLengths;
    }
    
    /**
     * 
     * @param aLengths int array of the lengths of a hiking trip
     */
    public void setLengths(int[] aLengths) {
        List<Integer> lengthList = new ArrayList<>();
        for (int i=0; i<aLengths.length; i++) {
            lengthList.add(aLengths[i]);
        }
        setLengths(lengthList);
    }
    
    @Override
    public String toString() {
        String string = this.name + " is a " + this.difficulty + " hike. ";
        string += "It can be for " + this.lengths + " days, and costs $";
        string += this.baseRate + "/day.";
        return string;
    }

    /**
     * @return the lengthComboBox
     */
    public DefaultComboBoxModel getLengthComboBox() {
        return lengthComboBox;
    }

    /**
     * @param lengthComboBox the lengthComboBox to set
     */
    public void setLengthComboBox(DefaultComboBoxModel lengthComboBox) {
        this.lengthComboBox = lengthComboBox;
    }
        

    
}
