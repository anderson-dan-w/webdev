/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dander73servlet1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webstart.*;

/**
 *
 * @author dwanderson
 */
@WebServlet(name = "HikeServlet", urlPatterns = {"/HikeServlet"})
public class HikeServlet extends HttpServlet {

    
    
    
    private static Map<String, Hike> hikeMap = Hike.makeHikeMap();
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String hikeQuote = "";
        try {
            String hike = request.getParameter("hikeName");
            int hikeLength = Integer.parseInt(request.getParameter("hikeLength"));
            int year = Integer.parseInt(request.getParameter("year"));
            int month = Integer.parseInt(request.getParameter("month"));
            int dayOfMonth = Integer.parseInt(request.getParameter("date"));
 
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Hike Quote</title>");
            out.println("</head>");
            out.println("<body>");
            hikeQuote = processFields(hike, hikeLength, year, month, dayOfMonth);
            out.println(hikeQuote);
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }
    
    private String processFields(String hikeName, int hikeLength,int year,
            int month, int day) {
        String hikeQuote = "";
        Hike hike = hikeMap.get(hikeName);
        if (hike == null) {
            return "Need to pick a hike from the approved list: we got '" + hikeName + "'.";
        }
        if (!hike.isValidLength(hikeLength)) {
            return ("This hike can only be for " + hike.getLengths() +
                    " days but you selected " + hikeLength);
        } 
        
        BookingDay startDate = new BookingDay(year, month, day);
        BookingDay endDate = startDate.getEndDate(hikeLength);
        Rates rate = new Rates();
        rate.setBeginDate(startDate);
        rate.setEndDate(endDate);
        if (!rate.isValidDates()) {
            return ("Either the start of the end of the hike is not " +
                "a valid hike date: " + rate.getDetails());
        }
        SocketClient sc = new SocketClient();
        hikeQuote += "For hike " + hikeName + " for " + hikeLength + " days,<br />";
        hikeQuote += "starting on " + startDate + " we can give you : $";
        hikeQuote += sc.getRate(startDate, endDate, hike);
        return hikeQuote;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
