/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webstart;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.text.*;

/**
 *
 * @author dwanderson
 */
public class WebStart extends JFrame implements ActionListener {
    private JComboBox hikeBox;
    private final JLabel startLabel = new JLabel("Enter start date (YYYY-MM-DD): ");
    private final JLabel endLabel = new JLabel("Choose a hike length: ");
    private JFormattedTextField startField;
    private JFormattedTextField endField;
    private MaskFormatter dateMask;
    private final JButton enterButton = new JButton("Calculate cost!");
    private final JLabel costLabel = new JLabel("Cost will appear here...");
    private final GridBagConstraints gbc = new GridBagConstraints();
    private Hike[] hikes;
    private JComboBox lengthComboBox;
    
    private JOptionPane errorPane;

    /**
     * Parses relevant information from all fields and attempts to calculate
     * the cost of a hike. Should provide helpful error message if something was
     * missing or wrong.
     * @param e 
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String errorString;
        Hike hike = (Hike)hikeBox.getSelectedItem();
        if (hike == null) {
            errorString = "Need to pick a hike!";
            JOptionPane.showMessageDialog(null, errorString, "Whoops", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] start = startField.getText().split("-");
        int startYear, startMonth, startDay;
        try {
            startYear = Integer.parseInt(start[0]);
            startMonth = Integer.parseInt(start[1]);
            startDay = Integer.parseInt(start[2]);
        } catch (NumberFormatException nfe) {
            errorString = "Need to enter dates for start and end!";
            JOptionPane.showMessageDialog(null, errorString, "Whoops", JOptionPane.ERROR_MESSAGE);
            costLabel.setText(errorString);
            return;
        }
        BookingDay startDate = new BookingDay(startYear, startMonth, startDay);
        int length = (int)lengthComboBox.getSelectedItem();
        if (length == 0) {
            costLabel.setText("Need to pick a hike length!");
            return;
        }
        BookingDay endDate = startDate.getEndDate(length - 1); //end-point inclusive!
        Rates rate = new Rates();
        rate.setBaseRate(hike.getBaseRate());
        rate.setBeginDate(startDate);
        rate.setEndDate(endDate);
        int numDays = rate.getNormalDays() + rate.getPremiumDays();
        if (rate.isValidDates() == false) {
            costLabel.setText(endDate + " : " + rate.getDetails());
        } else if (hike.isValidLength(numDays) == false) {
            costLabel.setText("Sorry, this hike can only be " +
                        hike.getLengths() + " days but you asked for" +
                        numDays + "days.");
        } else {
            SocketClient sc = new SocketClient();
            String rateInfo = sc.getRate(startDate, endDate, hike);
            costLabel.setText("Socket says: " + rateInfo);
        }
//        Rates rate = hike.calculateRate(startDate, endDate);
//        // rate.details is non-empty only if there was an error in processing
//        if (rate.getDetails().length() > 0) {
//            String details = rate.getDetails();
//            JOptionPane.showMessageDialog(null, details, "Whoops", JOptionPane.ERROR_MESSAGE);
//            costLabel.setText(details);
//        } else {
//            String cost = "Total cost: $" + rate.getCost() + " which includes " +
//                    rate.getNormalDays() + " weekdays and " + rate.getPremiumDays() +
//                    " weekend days.";
//            costLabel.setText(cost);
//        }
    }
    
    
    public WebStart() {
        super("Take a Hike!");
        
        // Make all our Hike objects and set them up
        hikes = Hike.makeHikes();
        hikeBox = new JComboBox(hikes);
        hikeBox.setRenderer(new HikeRenderer());
        // Last combobox is empty, start w that one:
        lengthComboBox = new JComboBox();
        lengthComboBox.setModel(new DefaultComboBoxModel());
        
        hikeBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Hike hike = (Hike)hikeBox.getSelectedItem();
                if (hike == null) {
                    lengthComboBox.setModel(new DefaultComboBoxModel());
                } else {
                    lengthComboBox.setModel(hike.getLengthComboBox());
                }
            }
        });
        
        // Setup our event handlers and other such settings
        enterButton.addActionListener(this);
        errorPane = new JOptionPane();
        // Set up dateMask for date input fields
        try {
            dateMask = new MaskFormatter("####-##-##");
            startField = new JFormattedTextField(dateMask);
            endField = new JFormattedTextField(dateMask);
            startField.setFont(new Font("monospaced", Font.PLAIN, 16));
            endField.setFont(new Font("monospaced", Font.PLAIN, 16));
        } catch (ParseException pe) {
            System.err.println("Couldn't parse Maskformatter field");
            System.exit(0);
        }
        
        // now let's make the panel itself
        setLayout(new GridBagLayout());
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.weightx = 0.0;
        add(hikeBox, gbc);
        add(startLabel, gbc);
        add(endLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(startField, gbc);
        gbc.gridy = GridBagConstraints.RELATIVE;
        //add(endField, gbc);
        add(lengthComboBox, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        add(enterButton, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        add(costLabel, gbc);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setSize(600, 200);
        setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Ok, kick things off.
        new WebStart();
    }
}
