/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mvc;

/**
 *
 * @author dwanderson
 */
public class HikeInfo {
    private String hikeName = "default";
    private String hikeLength = "";
    private String year = "";
    private String month = "";
    private String date = "";
    private String groupSize = "";
    private boolean valid = true;
    private double cost = 0;
    private String error = "";
    
    //NB: the isValid() function is what makes this a worthwhile piece of code;
    // everything else is just getters/setters
    /**
     * 
     * @return 
     */
    public boolean isValid() {
        BookingDay start = null;
        BookingDay end = null;
        double baseRate = 0;
        String dateString = "";
        if (hikeName.equals("The Beaten Path")) {
            if (!(hikeLength.equals("5") || hikeLength.equals("6") ||
                  hikeLength.equals("7"))) {
                setError("Beaten Path must be 5, 6 or 7 days long!");
                return false;
            }
            baseRate = 45.0;
        } else if (hikeName.equals("Gardiner Lake")) {
            if (!(hikeLength.equals("3") || hikeLength.equals("5"))) {
                setError("Beaten Path must be 3 or 5 days long!");
                return false;
            }
            baseRate = 40.0;
        } else if (hikeName.equals("Hellroaring Plateau")) {
            if (!(hikeLength.equals("2") || (hikeLength.equals("3")) ||
                    hikeLength.equals("4"))) {
                setError("Hellroaring Plateau must be 2, 3, or 4 days long!");
                return false;
            }
            baseRate = 35.0;
        } else {
            setError("We aren't exactly sure which hike you picked... " +
                     hikeName + " isn't on our list of hikes. Try again?");
            return false;
        }
        
        try {
            int yearInt = Integer.parseInt(year);
            int monthInt = Integer.parseInt(month);
            int dateInt = Integer.parseInt(date);
            int length = Integer.parseInt(hikeLength);
            start = new BookingDay(yearInt, monthInt, dateInt);
            end = start.getEndDate(length);
        } catch (NumberFormatException nfe) {
            setError("One of the year:month:day you entered weren't valid...");
            return false;
        }
        Rates rateObj = new Rates();
        rateObj.setBeginDate(start);
        rateObj.setEndDate(end);
        if (!(rateObj.isValidDates())) {
            setError(rateObj.getDetails());
            return false;
        }
        rateObj.setBaseRate(baseRate);
        double price = rateObj.getCost();
        setCost(price);
        return true;
    }
    
    /**
     * @return the hikeName
     */
    public String getHikeName() {
        return hikeName;
    }

    /**
     * @param hikeName the hikeName to set
     */
    public void setHikeName(String hikeName) {
        this.hikeName = hikeName;
    }

    /**
     * @return the hikeLength
     */
    public String getHikeLength() {
        return hikeLength;
    }

    /**
     * @param hikeLength the hikeLength to set
     */
    public void setHikeLength(String hikeLength) {
        this.hikeLength = hikeLength;
    }

    /**
     * @return the groupSize
     */
    public String getGroupSize() {
        return groupSize;
    }

    /**
     * @param groupSize the groupSize to set
     */
    public void setGroupSize(String groupSize) {
        this.groupSize = groupSize;
    }

    
    public double getCost() {
        return cost;
    }
    
    public void setCost(double cost) {
        this.cost = cost;
    }

    /**
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * @param error the error to set
     */
    public void setError(String error) {
        this.error = error;
    }

    /**
     * @return the year
     */
    public String getYear() {
        return year;
    }

    /**
     * @param year the year to set
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * @return the month
     */
    public String getMonth() {
        return month;
    }

    /**
     * @param month the month to set
     */
    public void setMonth(String month) {
        this.month = month;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }
}
