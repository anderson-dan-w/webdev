/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package mvc;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author dwanderson
 */
public class Controller extends HttpServlet {
    public static final String HIKEINFO = "hikeInfo";
    public static final String HIKENAME = "hikeName";
    public static final String HIKELENGTH = "hikeLength";
    public static final String YEAR = "year";
    public static final String MONTH = "month";
    public static final String DATE = "date";
    public static final String GROUPSIZE = "groupSize";
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        ServletContext servletContext = getServletContext();
        HikeInfo hikeInfo = (HikeInfo) session.getAttribute(HIKEINFO);
        if (hikeInfo == null) {
            hikeInfo = new HikeInfo();
            session.setAttribute(HIKEINFO, hikeInfo);
            RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/entryForm.jsp");
            dispatcher.forward(request, response);
        } else {
            String name = request.getParameter(HIKENAME);
            String length = request.getParameter(HIKELENGTH);
            String year = request.getParameter(YEAR);
            String month = request.getParameter(MONTH);
            String date = request.getParameter(DATE);
            String groupSize = request.getParameter(GROUPSIZE);
            
            if (name != null) {
                hikeInfo.setHikeName(name);
            } else {
                hikeInfo.setHikeName("The Beaten Path");
            }
            if (length != null) {
                hikeInfo.setHikeLength(length);
            } else {
                hikeInfo.setHikeLength("1");
            }
            if (year != null) {
                hikeInfo.setYear(year);
            } else {
                hikeInfo.setYear("2010");
            }
            if (month != null) {
                hikeInfo.setMonth(month);
            } else {
                hikeInfo.setMonth("1");
            }
            if (date != null) {
                hikeInfo.setDate(date);
            } else {
                hikeInfo.setDate("1");
            }
            if (groupSize != null) {
                hikeInfo.setGroupSize(groupSize);
            } else {
                hikeInfo.setGroupSize("1");
            }
            if (hikeInfo.isValid()) {
                RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/quote.jsp");
                dispatcher.forward(request, response);
            } else {
                RequestDispatcher dispatcher = servletContext.getRequestDispatcher("/entryForm.jsp");
                dispatcher.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
