/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webdevhw;

/**
 *
 * @author dwanderson
 */
public class WebDevHW {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Need to supply two arguments, please.");
            System.exit(1);
        }
        int first = Integer.parseInt(args[0]);
        int second = Integer.parseInt(args[1]);
        int result = multiply(first, second);
        System.out.println("Result of multiplying " + first + " and "
                + second + " is ");
        if (result < 0) {
            System.out.println("(" + (-1 * result) + ")");
        } else {
            System.out.println(result);
        }
        System.exit(0);
    }
    
    static int multiply(int a, int b) {
        return a * b;
    }
}
