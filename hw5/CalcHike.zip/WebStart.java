/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webstart;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;
import java.text.*;

/**
 *
 * @author dwanderson
 */
public class WebStart extends JFrame implements ActionListener {
    private JList hikeList;
    private final JLabel startLabel = new JLabel("Enter start date (YYYY-MM-DD): ");
    private final JLabel endLabel = new JLabel("End end date (YYYY-MM-DD): ");
    private JFormattedTextField startField;
    private JFormattedTextField endField;
    private MaskFormatter dateMask;
    private final JButton enterButton = new JButton("Calculate cost!");
    private final JLabel costLabel = new JLabel("Cost will appear here...");
    private final GridBagConstraints gbc = new GridBagConstraints();
    
    private JOptionPane errorPane;

    /**
     * Parses relevant information from all fields and attempts to calculate
     * the cost of a hike. Should provide helpful error message if something was
     * missing or wrong.
     * @param e 
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String errorString;
        Hike hike = (Hike)hikeList.getSelectedValue();
        if (hike == null) {
            errorString = "Need to pick a hike!";
            JOptionPane.showMessageDialog(null, errorString, "Whoops", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String[] start = startField.getText().split("-");
        String[] end = endField.getText().split("-");
        int startYear, startMonth, startDay, endYear, endMonth, endDay;
        try {
            startYear = Integer.parseInt(start[0]);
            startMonth = Integer.parseInt(start[1]);
            startDay = Integer.parseInt(start[2]);
            endYear = Integer.parseInt(end[0]);
            endMonth = Integer.parseInt(end[1]);
            endDay = Integer.parseInt(end[2]);
        } catch (NumberFormatException nfe) {
            errorString = "Need to enter dates for start and end!";
            JOptionPane.showMessageDialog(null, errorString, "Whoops", JOptionPane.ERROR_MESSAGE);
            costLabel.setText(errorString);
            return;
        }
        BookingDay startDate = new BookingDay(startYear, startMonth, startDay);
        BookingDay endDate = new BookingDay(endYear, endMonth, endDay);
        Rates rate = hike.calculateRate(startDate, endDate);
        // rate.details is non-empty only if there was an error in processing
        if (rate.getDetails().length() > 0) {
            String details = rate.getDetails();
            JOptionPane.showMessageDialog(null, details, "Whoops", JOptionPane.ERROR_MESSAGE);
            costLabel.setText(details);
        } else {
            String cost = "Total cost: $" + rate.getCost() + " which includes " +
                    rate.getNormalDays() + " weekdays and " + rate.getPremiumDays() +
                    " weekend days.";
            costLabel.setText(cost);
        }
    }
    
    
    public WebStart() {
        super("Take a Hike!");
        
        // Make all our Hike objects and set them up
        Hike[] hikes = Hike.makeHikes();
        hikeList = new JList(hikes);
        hikeList.setCellRenderer(new HikeRenderer());
        
        // Setup our event handlers and other such settings
        enterButton.addActionListener(this);
        errorPane = new JOptionPane();
        
        // Set up dateMask for date input fields
        try {
            dateMask = new MaskFormatter("####-##-##");
            startField = new JFormattedTextField(dateMask);
            endField = new JFormattedTextField(dateMask);
            startField.setFont(new Font("monospaced", Font.PLAIN, 16));
            endField.setFont(new Font("monospaced", Font.PLAIN, 16));
        } catch (ParseException pe) {
            System.err.println("Couldn't parse Maskformatter field");
            System.exit(0);
        }
        
        // now let's make the panel itself
        setLayout(new GridBagLayout());
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.weightx = 0.0;
        add(hikeList, gbc);
        add(startLabel, gbc);
        add(endLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(startField, gbc);
        gbc.gridy = GridBagConstraints.RELATIVE;
        add(endField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        add(enterButton, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        add(costLabel, gbc);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setSize(600, 200);
        setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Ok, kick things off.
        new WebStart();
    }
    
}
